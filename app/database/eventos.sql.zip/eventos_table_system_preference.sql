
-- --------------------------------------------------------

--
-- Estrutura para tabela `system_preference`
--
-- Criação: 21/08/2026 às 18:40
--

CREATE TABLE `system_preference` (
  `id` varchar(256) DEFAULT NULL,
  `value` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACIONAMENTOS PARA TABELAS `system_preference`:
--

--
-- Despejando dados para a tabela `system_preference`
--

INSERT INTO `system_preference` (`id`, `value`) VALUES
('mail_from', 'felabs@feituverava.com.br'),
('smtp_auth', '1'),
('smtp_host', 'smtp.gmail.com'),
('smtp_port', '465'),
('smtp_user', 'felabs@feituverava.com.br'),
('smtp_pass', 'ofzs otwo qxes yozx'),
('mail_support', NULL),
('term_policy', NULL);
