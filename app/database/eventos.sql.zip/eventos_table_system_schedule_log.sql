
-- --------------------------------------------------------

--
-- Estrutura para tabela `system_schedule_log`
--
-- Criação: 21/08/2026 às 22:08
--

CREATE TABLE `system_schedule_log` (
  `id` int(11) NOT NULL,
  `logdate` varchar(19) DEFAULT NULL,
  `title` varchar(256) DEFAULT NULL,
  `class_name` varchar(256) DEFAULT NULL,
  `method` varchar(256) DEFAULT NULL,
  `status` varchar(1) DEFAULT NULL,
  `message` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACIONAMENTOS PARA TABELAS `system_schedule_log`:
--
