
-- --------------------------------------------------------

--
-- Estrutura para tabela `system_unit`
--
-- Criação: 21/08/2026 às 22:05
--

CREATE TABLE `system_unit` (
  `id` int(11) NOT NULL,
  `name` varchar(256) DEFAULT NULL,
  `connection_name` varchar(256) DEFAULT NULL,
  `custom_code` varchar(256) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACIONAMENTOS PARA TABELAS `system_unit`:
--

--
-- Despejando dados para a tabela `system_unit`
--

INSERT INTO `system_unit` (`id`, `name`, `connection_name`, `custom_code`) VALUES
(1, 'Unit A', 'unit_a', NULL),
(2, 'Unit B', 'unit_b', NULL);
