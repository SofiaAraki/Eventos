
-- --------------------------------------------------------

--
-- Estrutura para tabela `system_access_notification_log`
--
-- Criação: 21/08/2026 às 18:40
--

CREATE TABLE `system_access_notification_log` (
  `id` int(11) NOT NULL,
  `login` varchar(256) DEFAULT NULL,
  `email` varchar(256) DEFAULT NULL,
  `ip_address` varchar(256) DEFAULT NULL,
  `login_time` varchar(256) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACIONAMENTOS PARA TABELAS `system_access_notification_log`:
--
