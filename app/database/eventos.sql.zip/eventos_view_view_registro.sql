
-- --------------------------------------------------------

--
-- Estrutura para view `view_registro`
--
DROP TABLE IF EXISTS `view_registro`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_registro`  AS SELECT `r`.`id_registro` AS `id_registro`, `r`.`id_inscricao` AS `id_inscricao`, `r`.`id_certificado` AS `id_certificado`, `r`.`data_registro` AS `data_registro`, `i`.`id_usuario` AS `id_usuario`, `i`.`id_evento` AS `id_evento`, `i`.`tipo_participacao` AS `tipo_participacao`, `i`.`status_inscricao` AS `status_inscricao`, `su`.`name` AS `usuario_name`, `e`.`titulo_evento` AS `evento_name`, `c`.`titulo_certificado` AS `certificado_name`, `c`.`descricao_certificado` AS `modelo_certificado`, `tp`.`descricao` AS `tipo_participacao_name` FROM (((((`registro` `r` join `inscricao` `i` on(`i`.`id_inscricao` = `r`.`id_inscricao`)) left join `system_users` `su` on(`su`.`id` = `i`.`id_usuario`)) left join `evento` `e` on(`e`.`id_evento` = `i`.`id_evento`)) left join `certificado` `c` on(`c`.`id_certificado` = `r`.`id_certificado`)) left join `tipos_participacao` `tp` on(`tp`.`codigo` = `i`.`tipo_participacao`)) ;
