
--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `autor`
--
ALTER TABLE `autor`
  ADD PRIMARY KEY (`id_autor`),
  ADD UNIQUE KEY `uq_autor` (`id_tcc`,`id_autor_usuario`),
  ADD KEY `id_autor_usuario` (`id_autor_usuario`);

--
-- Índices de tabela `banca`
--
ALTER TABLE `banca`
  ADD PRIMARY KEY (`id_banca`),
  ADD UNIQUE KEY `uq_banca` (`id_tcc`,`id_banca_usuario`),
  ADD KEY `id_banca_usuario` (`id_banca_usuario`);

--
-- Índices de tabela `certificado`
--
ALTER TABLE `certificado`
  ADD PRIMARY KEY (`id_certificado`),
  ADD UNIQUE KEY `uq_certificado` (`id_evento`,`tipo_participacao`),
  ADD KEY `fk_certificado_tipo_participacao` (`tipo_participacao`);

--
-- Índices de tabela `evento`
--
ALTER TABLE `evento`
  ADD PRIMARY KEY (`id_evento`),
  ADD KEY `gerente_evento` (`gerente_evento`);

--
-- Índices de tabela `inscricao`
--
ALTER TABLE `inscricao`
  ADD PRIMARY KEY (`id_inscricao`),
  ADD UNIQUE KEY `uq_inscricao` (`id_usuario`,`id_evento`,`tipo_participacao`),
  ADD KEY `fk_inscricao_evento` (`id_evento`),
  ADD KEY `fk_inscricao_tipo_participacao` (`tipo_participacao`);

--
-- Índices de tabela `monitor`
--
ALTER TABLE `monitor`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_monitor` (`id_evento`,`id_usuario`),
  ADD KEY `id_usuario` (`id_usuario`);

--
-- Índices de tabela `presenca`
--
ALTER TABLE `presenca`
  ADD PRIMARY KEY (`id_presenca`),
  ADD KEY `id_inscricao` (`id_inscricao`),
  ADD KEY `responsavel` (`responsavel`);

--
-- Índices de tabela `registro`
--
ALTER TABLE `registro`
  ADD PRIMARY KEY (`id_registro`),
  ADD UNIQUE KEY `uq_registro` (`id_inscricao`,`id_certificado`),
  ADD KEY `id_certificado` (`id_certificado`);

--
-- Índices de tabela `system_users`
--
ALTER TABLE `system_users`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `tcc`
--
ALTER TABLE `tcc`
  ADD PRIMARY KEY (`id_tcc`),
  ADD KEY `id_evento` (`id_evento`),
  ADD KEY `id_orientador` (`id_orientador`);

--
-- Índices de tabela `tipos_participacao`
--
ALTER TABLE `tipos_participacao`
  ADD PRIMARY KEY (`codigo`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `autor`
--
ALTER TABLE `autor`
  MODIFY `id_autor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=130;

--
-- AUTO_INCREMENT de tabela `banca`
--
ALTER TABLE `banca`
  MODIFY `id_banca` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=247;

--
-- AUTO_INCREMENT de tabela `certificado`
--
ALTER TABLE `certificado`
  MODIFY `id_certificado` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=680;

--
-- AUTO_INCREMENT de tabela `evento`
--
ALTER TABLE `evento`
  MODIFY `id_evento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=413;

--
-- AUTO_INCREMENT de tabela `inscricao`
--
ALTER TABLE `inscricao`
  MODIFY `id_inscricao` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9332;

--
-- AUTO_INCREMENT de tabela `monitor`
--
ALTER TABLE `monitor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT de tabela `presenca`
--
ALTER TABLE `presenca`
  MODIFY `id_presenca` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=647;

--
-- AUTO_INCREMENT de tabela `registro`
--
ALTER TABLE `registro`
  MODIFY `id_registro` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=136;

--
-- AUTO_INCREMENT de tabela `tcc`
--
ALTER TABLE `tcc`
  MODIFY `id_tcc` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=118;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `autor`
--
ALTER TABLE `autor`
  ADD CONSTRAINT `autor_ibfk_1` FOREIGN KEY (`id_tcc`) REFERENCES `tcc` (`id_tcc`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `autor_ibfk_2` FOREIGN KEY (`id_autor_usuario`) REFERENCES `system_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Restrições para tabelas `banca`
--
ALTER TABLE `banca`
  ADD CONSTRAINT `banca_ibfk_1` FOREIGN KEY (`id_tcc`) REFERENCES `tcc` (`id_tcc`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `banca_ibfk_2` FOREIGN KEY (`id_banca_usuario`) REFERENCES `system_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Restrições para tabelas `certificado`
--
ALTER TABLE `certificado`
  ADD CONSTRAINT `fk_certificado_evento` FOREIGN KEY (`id_evento`) REFERENCES `evento` (`id_evento`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_certificado_tipo_participacao` FOREIGN KEY (`tipo_participacao`) REFERENCES `tipos_participacao` (`codigo`) ON UPDATE CASCADE;

--
-- Restrições para tabelas `evento`
--
ALTER TABLE `evento`
  ADD CONSTRAINT `evento_ibfk_1` FOREIGN KEY (`gerente_evento`) REFERENCES `system_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Restrições para tabelas `inscricao`
--
ALTER TABLE `inscricao`
  ADD CONSTRAINT `fk_inscricao_evento` FOREIGN KEY (`id_evento`) REFERENCES `evento` (`id_evento`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_inscricao_tipo_participacao` FOREIGN KEY (`tipo_participacao`) REFERENCES `tipos_participacao` (`codigo`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_inscricao_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `system_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Restrições para tabelas `monitor`
--
ALTER TABLE `monitor`
  ADD CONSTRAINT `monitor_ibfk_1` FOREIGN KEY (`id_evento`) REFERENCES `evento` (`id_evento`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `monitor_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `system_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Restrições para tabelas `presenca`
--
ALTER TABLE `presenca`
  ADD CONSTRAINT `presenca_ibfk_1` FOREIGN KEY (`id_inscricao`) REFERENCES `inscricao` (`id_inscricao`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `presenca_ibfk_2` FOREIGN KEY (`responsavel`) REFERENCES `system_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Restrições para tabelas `registro`
--
ALTER TABLE `registro`
  ADD CONSTRAINT `registro_ibfk_1` FOREIGN KEY (`id_inscricao`) REFERENCES `inscricao` (`id_inscricao`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `registro_ibfk_2` FOREIGN KEY (`id_certificado`) REFERENCES `certificado` (`id_certificado`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Restrições para tabelas `tcc`
--
ALTER TABLE `tcc`
  ADD CONSTRAINT `tcc_ibfk_1` FOREIGN KEY (`id_evento`) REFERENCES `evento` (`id_evento`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tcc_ibfk_2` FOREIGN KEY (`id_orientador`) REFERENCES `system_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
