
-- --------------------------------------------------------

--
-- Estrutura para tabela `system_program`
--
-- Criação: 21/08/2026 às 18:40
-- Última atualização: 02/09/2026 às 19:03
--

CREATE TABLE `system_program` (
  `id` int(11) NOT NULL,
  `name` varchar(256) DEFAULT NULL,
  `controller` varchar(256) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACIONAMENTOS PARA TABELAS `system_program`:
--

--
-- Despejando dados para a tabela `system_program`
--

INSERT INTO `system_program` (`id`, `name`, `controller`) VALUES
(1, 'System Administration Dashboard', 'SystemAdministrationDashboard'),
(2, 'System Program Form', 'SystemProgramForm'),
(3, 'System Program List', 'SystemProgramList'),
(4, 'System Group Form', 'SystemGroupForm'),
(5, 'System Group List', 'SystemGroupList'),
(6, 'System Unit Form', 'SystemUnitForm'),
(7, 'System Unit List', 'SystemUnitList'),
(8, 'System Role Form', 'SystemRoleForm'),
(9, 'System Role List', 'SystemRoleList'),
(10, 'System User Form', 'SystemUserForm'),
(11, 'System User List', 'SystemUserList'),
(12, 'System Preference form', 'SystemPreferenceForm'),
(13, 'System Log Dashboard', 'SystemLogDashboard'),
(14, 'System Access Log', 'SystemAccessLogList'),
(15, 'System ChangeLog View', 'SystemChangeLogView'),
(16, 'System Sql Log', 'SystemSqlLogList'),
(17, 'System Request Log', 'SystemRequestLogList'),
(18, 'System Request Log View', 'SystemRequestLogView'),
(19, 'System PHP Error', 'SystemPHPErrorLogView'),
(20, 'System Session vars', 'SystemSessionVarsView'),
(21, 'System Database Browser', 'SystemDatabaseExplorer'),
(22, 'System Table List', 'SystemTableList'),
(23, 'System Data Browser', 'SystemDataBrowser'),
(24, 'System SQL Panel', 'SystemSQLPanel'),
(25, 'System Modules', 'SystemModulesCheckView'),
(26, 'System files diff', 'SystemFilesDiff'),
(27, 'System Information', 'SystemInformationView'),
(28, 'System PHP Info', 'SystemPHPInfoView'),
(29, 'Common Page', 'CommonPage'),
(30, 'Welcome View', 'WelcomeView'),
(31, 'Welcome dashboard', 'WelcomeDashboardView'),
(32, 'System Profile View', 'SystemProfileView'),
(33, 'System Profile Form', 'SystemProfileForm'),
(34, 'System Notification List', 'SystemNotificationList'),
(35, 'System Notification Form View', 'SystemNotificationFormView'),
(36, 'System Support form', 'SystemSupportForm'),
(37, 'System Profile 2FA Form', 'SystemProfile2FAForm'),
(38, 'System Wiki list', 'SystemWikiList'),
(39, 'System Wiki form', 'SystemWikiForm'),
(40, 'System Wiki page picker', 'SystemWikiPagePicker'),
(41, 'System Post list', 'SystemPostList'),
(42, 'System Post form', 'SystemPostForm'),
(43, 'System schedule list', 'SystemScheduleList'),
(44, 'System schedule form', 'SystemScheduleForm'),
(45, 'System schedule log', 'SystemScheduleLogList'),
(46, 'System Message Form', 'SystemMessageForm'),
(47, 'System Message List', 'SystemMessageList'),
(48, 'System Message Form View', 'SystemMessageFormView'),
(49, 'System Documents', 'SystemDriveList'),
(50, 'System Folder form', 'SystemFolderForm'),
(51, 'System Share folder', 'SystemFolderShareForm'),
(52, 'System Share document', 'SystemDocumentShareForm'),
(53, 'System Document properties', 'SystemDocumentFormWindow'),
(54, 'System Folder properties', 'SystemFolderFormView'),
(55, 'System Document upload', 'SystemDriveDocumentUploadForm'),
(56, 'Post View list', 'SystemPostFeedView'),
(57, 'Post Comment form', 'SystemPostCommentForm'),
(58, 'Post Comment list', 'SystemPostCommentList'),
(59, 'System Wiki search', 'SystemWikiSearchList'),
(60, 'System Wiki view', 'SystemWikiView'),
(61, 'System Message Tag form', 'SystemMessageTagForm'),
(62, 'System Contacts list', 'SystemContactsList'),
(63, 'Text document editor', 'SystemTextDocumentEditor'),
(64, 'System document create form', 'SystemDriveDocumentCreateForm'),
(65, 'System PHP Info', 'SystemPHPInfoView'),
(66, 'System ChangeLog View', 'SystemChangeLogView'),
(67, 'Welcome View', 'WelcomeView'),
(68, 'System Sql Log', 'SystemSqlLogList'),
(69, 'System Profile View', 'SystemProfileView'),
(70, 'System Profile Form', 'SystemProfileForm'),
(71, 'System SQL Panel', 'SystemSQLPanel'),
(72, 'System Access Log', 'SystemAccessLogList'),
(73, 'Certificado List', 'CertificadoList'),
(74, 'Eventos Abertos List', 'EventosAbertosList'),
(75, 'Evento List', 'EventoList'),
(76, 'Inscricao List', 'InscricaoList'),
(77, 'Registro List', 'RegistroList'),
(78, 'Minhas Inscricoes List', 'MinhasInscricoesList'),
(79, 'Evento Form', 'EventoForm'),
(80, 'Pagamentos Form View', 'PagamentosFormView'),
(81, 'Inscricao Form', 'InscricaoForm'),
(82, 'Certificado Form', 'CertificadoForm'),
(83, 'Emitir Certificados', 'EmitirCertificados'),
(84, 'Pagamentos View', 'PagamentosView'),
(85, 'Registro Form', 'RegistroForm'),
(86, 'Tcc List', 'TccList'),
(87, 'Tcc Form', 'TccForm'),
(88, 'Relatorio Evento', 'RelatorioEvento'),
(89, 'Evento Monitor List', 'EventoMonitorList'),
(90, 'Relatorio Evento Monitor', 'RelatorioEventoMonitor'),
(91, 'Scanner Page', 'ScannerPage'),
(92, 'Aprovacao List', 'AprovacaoList'),
(93, 'Solicitacao Evento Form Coordenador', 'SolicitacaoEventoFormCoordenador'),
(94, 'Public View', 'PublicView'),
(95, 'Solicitacao List Coordenador', 'SolicitacaoListCoordenador'),
(96, 'Solicitacao Certificado Form Coordenador', 'SolicitacaoCertificadoFormCoordenador'),
(97, 'Solicitacao Tcc Form Coordenador', 'SolicitacaoTccFormCoordenador'),
(98, 'Solicitacao Tcc List Coordenador', 'SolicitacaoTccListCoordenador'),
(99, 'Relatorio Evento Coordenador', 'RelatorioEventoCoordenador');
