
-- --------------------------------------------------------

--
-- Estrutura para tabela `system_program_method_role`
--
-- Criação: 21/08/2026 às 18:40
--

CREATE TABLE `system_program_method_role` (
  `id` int(11) NOT NULL,
  `system_program_id` int(11) DEFAULT NULL,
  `system_role_id` int(11) DEFAULT NULL,
  `method_name` varchar(256) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACIONAMENTOS PARA TABELAS `system_program_method_role`:
--
