
-- --------------------------------------------------------

--
-- Estrutura para tabela `system_post_share_group`
--
-- Criação: 21/08/2026 às 18:40
--

CREATE TABLE `system_post_share_group` (
  `id` int(11) NOT NULL,
  `system_group_id` int(11) DEFAULT NULL,
  `system_post_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACIONAMENTOS PARA TABELAS `system_post_share_group`:
--
