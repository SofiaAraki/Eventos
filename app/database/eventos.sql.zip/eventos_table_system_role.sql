
-- --------------------------------------------------------

--
-- Estrutura para tabela `system_role`
--
-- Criação: 21/08/2026 às 22:03
--

CREATE TABLE `system_role` (
  `id` int(11) NOT NULL,
  `name` varchar(256) DEFAULT NULL,
  `custom_code` varchar(256) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACIONAMENTOS PARA TABELAS `system_role`:
--

--
-- Despejando dados para a tabela `system_role`
--

INSERT INTO `system_role` (`id`, `name`, `custom_code`) VALUES
(1, 'Role A', ''),
(2, 'Role B', '');
