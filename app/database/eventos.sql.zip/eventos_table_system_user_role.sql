
-- --------------------------------------------------------

--
-- Estrutura para tabela `system_user_role`
--
-- Criação: 21/08/2026 às 21:20
--

CREATE TABLE `system_user_role` (
  `id` int(11) NOT NULL,
  `system_user_id` int(11) DEFAULT NULL,
  `system_role_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACIONAMENTOS PARA TABELAS `system_user_role`:
--

--
-- Despejando dados para a tabela `system_user_role`
--

INSERT INTO `system_user_role` (`id`, `system_user_id`, `system_role_id`) VALUES
(1, 2955, 1);
