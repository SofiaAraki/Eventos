
-- --------------------------------------------------------

--
-- Estrutura para tabela `system_sql_changes`
--
-- Criação: 21/08/2026 às 22:08
--

CREATE TABLE `system_sql_changes` (
  `id` int(11) NOT NULL,
  `db_name` varchar(200) DEFAULT NULL,
  `sql_date` varchar(20) DEFAULT NULL,
  `sql_hash` varchar(32) DEFAULT NULL,
  `sql_command` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACIONAMENTOS PARA TABELAS `system_sql_changes`:
--
