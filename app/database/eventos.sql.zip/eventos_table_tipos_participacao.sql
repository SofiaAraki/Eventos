
-- --------------------------------------------------------

--
-- Estrutura para tabela `tipos_participacao`
--
-- Criação: 21/08/2026 às 21:24
--

CREATE TABLE `tipos_participacao` (
  `codigo` varchar(20) NOT NULL,
  `descricao` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACIONAMENTOS PARA TABELAS `tipos_participacao`:
--

--
-- Despejando dados para a tabela `tipos_participacao`
--

INSERT INTO `tipos_participacao` (`codigo`, `descricao`) VALUES
('aluno', 'Aluno'),
('autor', 'Autor'),
('banca', 'Banca'),
('organizador', 'Organizador'),
('orientador', 'Orientador'),
('palestrante', 'Palestrante');
