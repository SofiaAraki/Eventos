
-- --------------------------------------------------------

--
-- Estrutura para tabela `system_schedule`
--
-- Criação: 21/08/2026 às 22:08
--

CREATE TABLE `system_schedule` (
  `id` int(11) NOT NULL,
  `schedule_type` char(1) DEFAULT NULL,
  `title` varchar(256) DEFAULT NULL,
  `class_name` varchar(256) DEFAULT NULL,
  `method` varchar(256) DEFAULT NULL,
  `monthday` char(2) DEFAULT NULL,
  `weekday` char(1) DEFAULT NULL,
  `hour` char(2) DEFAULT NULL,
  `minute` char(2) DEFAULT NULL,
  `active` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACIONAMENTOS PARA TABELAS `system_schedule`:
--
