
-- --------------------------------------------------------

--
-- Estrutura para tabela `system_message`
--
-- Criação: 21/08/2026 às 18:40
--

CREATE TABLE `system_message` (
  `id` int(11) NOT NULL,
  `system_user_id` int(11) DEFAULT NULL,
  `system_user_to_id` int(11) DEFAULT NULL,
  `subject` varchar(256) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `dt_message` varchar(20) DEFAULT NULL,
  `checked` char(1) DEFAULT NULL,
  `removed` char(1) DEFAULT NULL,
  `viewed` char(1) DEFAULT NULL,
  `attachments` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACIONAMENTOS PARA TABELAS `system_message`:
--
