
-- --------------------------------------------------------

--
-- Estrutura para tabela `monitor`
--
-- Criação: 21/08/2026 às 18:39
-- Última atualização: 14/09/2026 às 12:50
--

CREATE TABLE `monitor` (
  `id` int(11) NOT NULL,
  `id_evento` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACIONAMENTOS PARA TABELAS `monitor`:
--   `id_evento`
--       `evento` -> `id_evento`
--   `id_usuario`
--       `system_users` -> `id`
--

--
-- Despejando dados para a tabela `monitor`
--

INSERT INTO `monitor` (`id`, `id_evento`, `id_usuario`) VALUES
(57, 397, 1632),
(58, 397, 1778),
(59, 397, 1814),
(60, 397, 1816),
(61, 397, 1817),
(62, 397, 1818),
(63, 397, 1819),
(64, 397, 1820),
(65, 397, 1942),
(66, 397, 1944),
(67, 412, 1778);
