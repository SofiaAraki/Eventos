
-- --------------------------------------------------------

--
-- Estrutura para tabela `system_group`
--
-- Criação: 21/08/2026 às 18:40
--

CREATE TABLE `system_group` (
  `id` int(11) NOT NULL,
  `name` varchar(256) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACIONAMENTOS PARA TABELAS `system_group`:
--

--
-- Despejando dados para a tabela `system_group`
--

INSERT INTO `system_group` (`id`, `name`) VALUES
(3, 'Application - Programs'),
(4, 'Financeiro'),
(6, 'Monitor'),
(5, 'Participante'),
(1, 'Template - Admin'),
(2, 'Template - Users'),
(7, 'Coordenador'),
(8, 'Gerente');
