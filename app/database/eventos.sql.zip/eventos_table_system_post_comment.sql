
-- --------------------------------------------------------

--
-- Estrutura para tabela `system_post_comment`
--
-- Criação: 21/08/2026 às 18:40
--

CREATE TABLE `system_post_comment` (
  `id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `system_user_id` int(11) NOT NULL,
  `system_post_id` int(11) NOT NULL,
  `created_at` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACIONAMENTOS PARA TABELAS `system_post_comment`:
--
