
-- --------------------------------------------------------

--
-- Estrutura para tabela `system_document_user`
--
-- Criação: 21/08/2026 às 18:40
--

CREATE TABLE `system_document_user` (
  `id` int(11) NOT NULL,
  `document_id` int(11) DEFAULT NULL,
  `system_user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACIONAMENTOS PARA TABELAS `system_document_user`:
--
