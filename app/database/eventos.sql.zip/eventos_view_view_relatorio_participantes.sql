
-- --------------------------------------------------------

--
-- Estrutura para view `view_relatorio_participantes`
--
DROP TABLE IF EXISTS `view_relatorio_participantes`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_relatorio_participantes`  AS SELECT `i`.`id_inscricao` AS `id_inscricao`, `i`.`id_evento` AS `id_evento`, `i`.`id_usuario` AS `id_usuario`, `i`.`status_inscricao` AS `status_inscricao`, `u`.`name` AS `usuario_name`, `u`.`email` AS `usuario_email`, CASE WHEN `i`.`status_inscricao` = 1 THEN 'Confirmado' WHEN `i`.`status_inscricao` = 0 THEN 'Pendente' ELSE 'Cancelado' END AS `status_label`, coalesce(sum(case when `p`.`data_saida` is null and `p`.`id_presenca` is not null then 1 else 0 end),0) AS `esta_presente`, coalesce(sum(case when `p`.`data_saida` is not null then 1 else 0 end),0) AS `ja_saiu`, coalesce(sum(`p`.`permanencia_min`),0) AS `total_minutos`, max(`p`.`data_entrada`) AS `ultima_entrada`, max(`p`.`data_saida`) AS `ultima_saida`, cast(max(`p`.`data_entrada`) as date) AS `dia_evento`, (select `su`.`name` from (`presenca` `p2` left join `system_users` `su` on(`su`.`id` = `p2`.`responsavel`)) where `p2`.`id_inscricao` = `i`.`id_inscricao` order by `p2`.`id_presenca` desc limit 1) AS `responsavel_nome` FROM ((`inscricao` `i` join `system_users` `u` on(`u`.`id` = `i`.`id_usuario`)) left join `presenca` `p` on(`p`.`id_inscricao` = `i`.`id_inscricao`)) GROUP BY `i`.`id_inscricao`, `i`.`id_evento`, `i`.`id_usuario`, `i`.`status_inscricao`, `u`.`name`, `u`.`email` ;
